﻿using Microsoft.EntityFrameworkCore;
using Task_Management_System_API.Src.Application.Interfaces.Repositories;
using Task_Management_System_API.Src.Infrastructure.AppDBContext;
using Task_Management_System_API.Src.Infrastructure.Repositories;

namespace Task_Management_System_API.Src.Infrastructure.DependencyInjection
{
    public static class InfrastructureServiceRegistration
    {
       
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("DefaultConnection");
            services.AddDbContext<AppDbContext>(options => options.UseSqlServer(connectionString));
            services.AddScoped<ITaskRepository, TaskRepository>();
            services.AddScoped<IProjectRepository, ProjectRepository>();
            //services.AddScoped<IJwtService, JwtService>();

            return services;
        }
    }
}
