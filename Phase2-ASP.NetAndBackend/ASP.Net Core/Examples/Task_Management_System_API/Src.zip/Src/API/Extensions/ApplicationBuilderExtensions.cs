﻿using Task_Management_System_API.Src.API.Middlewares;

namespace Task_Management_System_API.Src.API.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static IApplicationBuilder UseCustomMiddleware(this IApplicationBuilder app)
        {
          
            app.UseMiddleware<GlobalExceptionMiddleware>();
            return app;
        }

    }
}
