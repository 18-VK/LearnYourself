﻿using Microsoft.EntityFrameworkCore;
using Task_Management_System_API.Src.Application.Exceptions;
using Task_Management_System_API.Src.Application.Interfaces.Repositories;
using Task_Management_System_API.Src.Domain.Entities;
using Task_Management_System_API.Src.Infrastructure.AppDBContext;

namespace Task_Management_System_API.Src.Infrastructure.Repositories
{
    public class ProjectRepository : IProjectRepository
    {
        private readonly AppDbContext _appContext;
        private readonly ILogger<ProjectRepository> _logger;

        /* Note : Exception handling : we should log the exception here for diagnose and throw custom exception to service layer
            
            - Log at the infrastructure layer for diagnostics.
            - Translate at the service layer into domain‑specific exceptions or results.
            - Return clean API responses from the controller (e.g., NotFound, BadRequest, 500 with a friendly message).
            - Avoid leaking SQL details or EF Core stack traces to clients.
        */
        public ProjectRepository(AppDbContext appContext, ILogger<ProjectRepository> logger) 
        {
            _appContext = appContext;
            _logger = logger;
        }

        public async Task<bool> Addproject(Projects Obj, CancellationToken ct)
        {
            if (Obj == null) throw new ArgumentNullException(nameof(Obj));

            try
            {
                await _appContext.Projects.AddAsync(Obj, ct);
                return await _appContext.SaveChangesAsync(ct) > 0;
        
            }
            catch(Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return false;
            }
        }

        public async Task<bool> Deleteproject(Guid id, CancellationToken ct)
        {
            try
            {
                return await _appContext.Projects.Where(p => p.Id == id).ExecuteDeleteAsync(ct) > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return false;
            }
        }

        public async Task<List<Projects>?> GetprojectsPageAsync(int page, CancellationToken ct, int pageSize)
        {
            if (page < 1) page = 1;
            if (pageSize <= 0) pageSize = 100;
            try
            {
                return await _appContext.Projects
                                    .AsNoTracking()
                                    .OrderBy(p => p.Id)
                                    .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }

        public async Task<Projects?> GetprojectById(Guid id, CancellationToken ct)
        {
            try
            {
                return await _appContext.Projects.FindAsync(id, ct) ?? default;
            }
            catch(Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }

        public async Task<bool> Updateproject(Projects Obj, CancellationToken ct)
        {
            const int Defaultretry = 3; 
            int currentcount = 0;

        retry:
            if (Obj is null) return false;

            //var existing = await _appContext.Projects.FindAsync(Obj.Id, ct);
            //if (existing is null) return false;

            //_appContext.Entry(Obj).CurrentValues.SetValues(Obj);

            try
            {
                return await _appContext.SaveChangesAsync(ct) > 0;
            }
            catch (DbUpdateConcurrencyException ex)
            {
                currentcount++;
                if (currentcount > Defaultretry)
                {
                    _logger.LogDebug($"Concurrency conflict detected|Source : {ex.Source}, Error Description : {ex.Message}, Retry count exhausted : {currentcount}");
                    return false;
                }
                // added wait delay
                await Task.Delay(100, ct);
                _logger.LogDebug($"Concurrency conflict detected|Source : {ex.Source}, Error Description : {ex.Message}, Retry count : {currentcount}");
                goto retry;
            }
            catch(Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return false;
            }
        }

        public async Task<Projects?> GetprojectByName(string name, CancellationToken ct)
        {
            if(String.IsNullOrEmpty(name)) return default;
            
            try
            {

                return await _appContext.Projects.Where(x => x.Name == name)
                                .FirstOrDefaultAsync(ct);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }

        public async Task<List<Tasks>?> GetTasksForProject(Guid id, CancellationToken ct)
        {
            try
            {

                return await _appContext.Tasks
                                .AsNoTracking()
                                .Where(t => t.ProjectId == id)
                                .ToListAsync(ct);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }
    }
}
