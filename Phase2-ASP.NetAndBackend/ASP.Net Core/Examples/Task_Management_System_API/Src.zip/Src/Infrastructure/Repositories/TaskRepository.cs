﻿using Microsoft.EntityFrameworkCore;
using System.Transactions;
using Task_Management_System_API.Src.API.DTOs.Requests.Tasks;
using Task_Management_System_API.Src.Application.DTOs;
using Task_Management_System_API.Src.Application.Interfaces.Repositories;
using Task_Management_System_API.Src.Domain.Entities;
using Task_Management_System_API.Src.Infrastructure.AppDBContext;

namespace Task_Management_System_API.Src.Infrastructure.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private readonly AppDbContext _appContext;
        private readonly ILogger<TaskRepository> _logger;
        public TaskRepository(AppDbContext appContext, ILogger<TaskRepository> logger) 
        {
            _appContext = appContext;
            _logger = logger;
        }

        public async Task<bool> Addtask(Tasks obj, CancellationToken ct)
        {
            if (obj == null) throw new ArgumentNullException(nameof(obj));

            try
            {
                await _appContext.Tasks.AddAsync(obj, ct);
                return await _appContext.SaveChangesAsync(ct) > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return false;
            }
        }

        public async Task<bool> Deletetask(Guid id, CancellationToken ct)
        {
            try
            {
                return await _appContext.Tasks.Where(t => t.Id == id).ExecuteDeleteAsync(ct) > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return false;
            }
        }

        public async Task<List<Tasks>?> GetTasksPageAsync(int page, CancellationToken ct, int pageSize)
        {
            try
            {

                if (page < 1) page = 1;
                if (pageSize <= 0) pageSize = 100;

                return await _appContext.Tasks.AsNoTracking()
                            .OrderBy(t => t.Id)
                            .Skip((page -1) * pageSize).Take(pageSize).ToListAsync(ct);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }

        public async Task<Tasks?> GettaskById(Guid id, CancellationToken ct)
        {
            // if null(mean not found) then return default(that is null)
            try
            {
                return await _appContext.Tasks.FindAsync(id, ct) ?? default;
            }
            catch(Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }

        public async Task<bool> Updatetask(Tasks Obj, CancellationToken ct)
        {

            const int Defaultretry = 3;
            int currentcount = 0;

        retry:
            if (Obj == null) return false;

            //var existing = await _appContext.Tasks.FindAsync(Obj.Id, ct);
            //if (existing == null) return false; // entity not found

            //// Update only the properties you want to allow
            //_appContext.Entry(existing).CurrentValues.SetValues(Obj);

            try
            {
                return await _appContext.SaveChangesAsync(ct) > 0;
            }
            catch (DbUpdateConcurrencyException ex)
            {
                currentcount++;
                if (currentcount > Defaultretry)
                {
                    _logger.LogDebug($"Concurrency conflict detected|Source : {ex.Source}, Error Description : {ex.Message}, Retry count exhausted : {currentcount}");
                    return false;
                }
                // added wait delay
                await Task.Delay(100, ct);
                _logger.LogDebug($"Concurrency conflict detected|Source : {ex.Source}, Error Description : {ex.Message}, Retry count : {currentcount}");
                goto retry;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }

        public async Task<Tasks?> GetTaskByName(string name, CancellationToken ct)
        {
            if (String.IsNullOrEmpty(name)) return default;

            try
            {

                return await _appContext.Tasks.Where(x => x.Title == name)
                                .FirstOrDefaultAsync(ct);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception|Source : {ex.Source}, Error Description : {ex.Message}");
                return default;
            }
        }

        public async Task<Projects?> GetProjectByTaskId(Guid taskId, CancellationToken ct)
        {
            try
            {
                return await _appContext.Projects
                    .Where(p => p.TaskItems.Any(t => t.Id == taskId))
                    .FirstOrDefaultAsync(ct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error fetching project for TaskId {taskId}");
                return null;
            }
        }

        public async Task<List<Tasks>?> ApplyFilterAsync(TaskFilterDTO filter, CancellationToken ct)
        {
            try
            {

                var query = _appContext.Tasks.AsNoTracking();

                // Status Filter
                if (filter.Status.HasValue)
                {
                    query = query.Where(x => x.Status == filter.Status.Value);

                }
                // Priority Filter
                if (filter.Priority.HasValue)
                {
                    query = query.Where(x => x.Priority == filter.Priority.Value);

                }

                // Due Date Filter
                if (filter.DueDate.HasValue)
                {
                    query = query.Where(x => DateOnly.FromDateTime(x.DueDate) == filter.DueDate.Value);
                }

                var tasks = await query.OrderBy(t => t.Id)
                                        .Skip((filter.Page - 1) * filter.PageSize).Take(filter.PageSize)
                                        .ToListAsync(ct);
                return tasks;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching tasks using filters");
                return null;
            }
        }
    }
}
