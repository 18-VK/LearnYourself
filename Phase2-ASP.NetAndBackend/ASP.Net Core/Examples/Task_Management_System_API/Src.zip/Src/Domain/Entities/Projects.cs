﻿namespace Task_Management_System_API.Src.Domain.Entities
{
    public class Projects
    {
        public Guid Id { get; set; }    
        public string Name { get; set; } = String.Empty;    
        public string Description { get; set; } = String.Empty; 
        public DateTime DueDate { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public List<Tasks> TaskItems { get; set; } = new List<Tasks>();
    }
}
