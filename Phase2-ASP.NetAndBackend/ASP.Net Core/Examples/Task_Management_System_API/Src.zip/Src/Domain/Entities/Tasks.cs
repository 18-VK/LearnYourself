﻿using Task_Management_System_API.Src.Domain.Enums;

namespace Task_Management_System_API.Src.Domain.Entities
{
    public class Tasks
    {
        public Guid Id { get; set; }
        public Guid ProjectId { get; set; }
        public Projects? Project { get; set; }
        public string Title { get; set; } = String.Empty;
        public string Description { get; set; } = String.Empty;
        public TaskItemStatus Status { get; set; }
        public TaskPriority Priority { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set;}
    }
}
