﻿using Microsoft.EntityFrameworkCore;
using Task_Management_System_API.Src.Domain.Entities;

namespace Task_Management_System_API.Src.Infrastructure.AppDBContext
{
    public class AppDbContext : DbContext
    {
        // table set 
        public DbSet<Tasks> Tasks => Set<Tasks>();
        public DbSet<Projects> Projects => Set<Projects>();

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // call fluent API Configuration 

            // Scans the assembly for any class implementing IEntityTypeConfiguration
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        }
    }
}
