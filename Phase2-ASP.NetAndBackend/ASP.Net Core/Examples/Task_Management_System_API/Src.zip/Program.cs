using Microsoft.EntityFrameworkCore;
using Serilog;
using Task_Management_System_API.Src.API.Extensions;
using Task_Management_System_API.Src.API.Filters;
using Task_Management_System_API.Src.Infrastructure.AppDBContext;
using Task_Management_System_API.Src.Infrastructure.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers(options =>
{
    options.Filters.Add<ValidationFilter>();
});
builder.Host.UseDefaultServiceProvider((options) =>
{
    options.ValidateOnBuild = true;
    options.ValidateScopes = true;
});


// log
Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(builder.Configuration).CreateLogger();
builder.Host.UseSerilog(Log.Logger);

//ApplicationServices
builder.Services.AddApplicationServices();
// Infrastructure services 
builder.Services.AddInfrastructure(builder.Configuration);


// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();
builder.Services.AddSwaggerGen();


var app = builder.Build();

app.UseCustomMiddleware();
app.UseRequiredPipeline();

app.Run();
